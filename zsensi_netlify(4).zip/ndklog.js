/* Excerpts:
   Copyright (c) 2008, The Android Open Source Project

   Modifications:
   Copyright (c) 2015, Jorrit 'Chainfire' Jongma

   See LICENSE file for details */

// Version JavaScript de ndklog.h

var LOG_TAG = "NDK_LOG";

// Definir constantes para niveles de log
var ANDROID_LOG_VERBOSE = 2;
var ANDROID_LOG_DEBUG = 3;
var ANDROID_LOG_INFO = 4;
var ANDROID_LOG_WARN = 5;
var ANDROID_LOG_ERROR = 6;

// Funciones de logging
function LOG(level, tag, message) {
    switch (level) {
        case ANDROID_LOG_VERBOSE:
            console.log(`[V/${tag}] ${message}`);
            break;
        case ANDROID_LOG_DEBUG:
            console.debug(`[D/${tag}] ${message}`);
            break;
        case ANDROID_LOG_INFO:
            console.info(`[I/${tag}] ${message}`);
            break;
        case ANDROID_LOG_WARN:
            console.warn(`[W/${tag}] ${message}`);
            break;
        case ANDROID_LOG_ERROR:
            console.error(`[E/${tag}] ${message}`);
            break;
        default:
            console.log(`[?/${tag}] ${message}`);
    }
}

// Función para formatear mensajes con argumentos variables (similar a printf)
function format(fmt, ...args) {
    var i = 0;
    return fmt.replace(/%s|%d|%f|%j/g, match => {
        var arg = args[i++];
        switch (match) {
            case '%s': return String(arg);
            case '%d': return Number(arg);
            case '%f': return parseFloat(arg);
            case '%j': return JSON.stringify(arg);
            default: return match;
        }
    });
}

// Funciones de logging con nivel específico
function LOGV(fmt, ...args) {
    LOG(ANDROID_LOG_VERBOSE, LOG_TAG, format(fmt, ...args));
}

function LOGD(fmt, ...args) {
    LOG(ANDROID_LOG_DEBUG, LOG_TAG, format(fmt, ...args));
}

function LOGI(fmt, ...args) {
    LOG(ANDROID_LOG_INFO, LOG_TAG, format(fmt, ...args));
}

function LOGW(fmt, ...args) {
    LOG(ANDROID_LOG_WARN, LOG_TAG, format(fmt, ...args));
}

function LOGE(fmt, ...args) {
    LOG(ANDROID_LOG_ERROR, LOG_TAG, format(fmt, ...args));
}

// Funciones condicionales
function CONDITION(cond) {
    return cond !== 0;
}

function LOGV_IF(cond, fmt, ...args) {
    if (CONDITION(cond)) LOGV(fmt, ...args);
}

function LOGD_IF(cond, fmt, ...args) {
    if (CONDITION(cond)) LOGD(fmt, ...args);
}

function LOGI_IF(cond, fmt, ...args) {
    if (CONDITION(cond)) LOGI(fmt, ...args);
}

function LOGW_IF(cond, fmt, ...args) {
    if (CONDITION(cond)) LOGW(fmt, ...args);
}

function LOGE_IF(cond, fmt, ...args) {
    if (CONDITION(cond)) LOGE(fmt, ...args);
}

// Exportar funciones globalmente
window.LOG_TAG = LOG_TAG;
window.ANDROID_LOG_VERBOSE = ANDROID_LOG_VERBOSE;
window.ANDROID_LOG_DEBUG = ANDROID_LOG_DEBUG;
window.ANDROID_LOG_INFO = ANDROID_LOG_INFO;
window.ANDROID_LOG_WARN = ANDROID_LOG_WARN;
window.ANDROID_LOG_ERROR = ANDROID_LOG_ERROR;
window.LOG = LOG;
window.LOGV = LOGV;
window.LOGD = LOGD;
window.LOGI = LOGI;
window.LOGW = LOGW;
window.LOGE = LOGE;
window.LOGV_IF = LOGV_IF;
window.LOGD_IF = LOGD_IF;
window.LOGI_IF = LOGI_IF;
window.LOGW_IF = LOGW_IF;
window.LOGE_IF = LOGE_IF;