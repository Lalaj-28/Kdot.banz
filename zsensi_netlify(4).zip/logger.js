//#ifndef LOGGER_H
//#define LOGGER_H

//#include <android/log.h>

//Log
var TAG = "Musk modz";
function LOGI() { console.info.apply(console, [`[${TAG}]`].concat(Array.from(arguments))); }
function LOGW() { console.warn.apply(console, [`[${TAG}]`].concat(Array.from(arguments))); }
function LOGD() { console.debug.apply(console, [`[${TAG}]`].concat(Array.from(arguments))); }
function LOGE() { console.error.apply(console, [`[${TAG}]`].concat(Array.from(arguments))); }

//#endif //LOGGER_H