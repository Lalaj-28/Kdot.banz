/**
 * Módulo FloatingMod para web
 * Adaptado de la versión Android para funcionar en navegadores web
 */

class FloatingMod {
    constructor() {
        this.enabled = false;
        this.features = {};
        this.initialized = false;
        this.dragging = false;
        this.offsetX = 0;
        this.offsetY = 0;
        this.menuElement = null;
        this.buttonPanel = null;
        this.collapsed = null;
        this.expanded = null;
        this.soundEnabled = true;
        this.playerFX = null;
        this.dpi = window.devicePixelRatio || 1;
        this.screenWidth = window.innerWidth;
        this.screenHeight = window.innerHeight;
    }

    /**
     * Inicializa el menú flotante
     */
    initialize() {
        if (this.initialized) return;
        this.initialized = true;
        
        console.log("[FloatingMod] Inicializando...");
        
        // Crear elementos principales
        this.createElements();
        
        // Añadir oyentes de eventos
        this.addEventListeners();
        
        // Cargar preferencias
        this.loadPreferences();
        
        // Inicializar sonidos
        this.initSounds();
        
        console.log("[FloatingMod] Menú inicializado correctamente");
    }
    
    /**
     * Crea los elementos DOM necesarios para el menú
     */
    createElements() {
        // Crear contenedor principal
        this.menuElement = document.createElement('div');
        this.menuElement.id = 'floating-mod-menu';
        this.menuElement.className = 'floating-mod';
        this.menuElement.style.position = 'fixed';
        this.menuElement.style.top = '100px';
        this.menuElement.style.left = '20px';
        this.menuElement.style.zIndex = '9999';
        this.menuElement.style.userSelect = 'none';
        this.menuElement.style.touchAction = 'none';
        
        // Crear vista colapsada
        this.collapsed = document.createElement('div');
        this.collapsed.className = 'mod-collapsed';
        this.collapsed.style.width = '60px';
        this.collapsed.style.height = '60px';
        this.collapsed.style.borderRadius = '30px';
        this.collapsed.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
        this.collapsed.style.display = 'flex';
        this.collapsed.style.alignItems = 'center';
        this.collapsed.style.justifyContent = 'center';
        this.collapsed.style.cursor = 'pointer';
        this.collapsed.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
        
        // Icono del botón colapsado
        const icon = document.createElement('div');
        icon.innerHTML = '⚙️';
        icon.style.fontSize = '30px';
        this.collapsed.appendChild(icon);
        
        // Crear vista expandida
        this.expanded = document.createElement('div');
        this.expanded.className = 'mod-expanded';
        this.expanded.style.width = '250px';
        this.expanded.style.backgroundColor = 'rgba(0, 0, 0, 0.85)';
        this.expanded.style.borderRadius = '10px';
        this.expanded.style.padding = '10px';
        this.expanded.style.display = 'none';
        this.expanded.style.flexDirection = 'column';
        this.expanded.style.color = 'white';
        this.expanded.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.4)';
        
        // Título del menú expandido
        const title = document.createElement('h2');
        title.textContent = 'ZSensi Mod Menu';
        title.style.textAlign = 'center';
        title.style.margin = '0 0 10px 0';
        title.style.padding = '5px';
        title.style.borderBottom = '1px solid rgba(255, 255, 255, 0.3)';
        this.expanded.appendChild(title);
        
        // Panel de características
        const features = document.createElement('div');
        features.className = 'features-panel';
        features.style.display = 'flex';
        features.style.flexDirection = 'column';
        features.style.gap = '8px';
        features.style.maxHeight = '300px';
        features.style.overflowY = 'auto';
        features.style.padding = '5px';
        
        // Agregar características de ejemplo
        this.addFeatureToPanel(features, 'feature_1', 'Calibrar sensibilidad');
        this.addFeatureToPanel(features, 'feature_2', 'Reduzir recuo');
        this.addFeatureToPanel(features, 'feature_3', 'Aumentar precisão');
        this.addFeatureToPanel(features, 'feature_4', 'Retirar input lag');
        
        this.expanded.appendChild(features);
        
        // Panel de botones
        this.buttonPanel = document.createElement('div');
        this.buttonPanel.className = 'button-panel';
        this.buttonPanel.style.display = 'flex';
        this.buttonPanel.style.justifyContent = 'space-between';
        this.buttonPanel.style.marginTop = '10px';
        
        // Botón de inyectar
        const injectBtn = document.createElement('button');
        injectBtn.textContent = 'Injetar';
        injectBtn.className = 'inject-button';
        injectBtn.style.backgroundColor = '#1a73e8';
        injectBtn.style.color = 'white';
        injectBtn.style.border = 'none';
        injectBtn.style.padding = '8px 15px';
        injectBtn.style.borderRadius = '5px';
        injectBtn.style.cursor = 'pointer';
        
        // Botón de cerrar
        const closeBtn = document.createElement('button');
        closeBtn.textContent = 'Sair';
        closeBtn.className = 'close-button';
        closeBtn.style.backgroundColor = '#3a3a3a';
        closeBtn.style.color = 'white';
        closeBtn.style.border = 'none';
        closeBtn.style.padding = '8px 15px';
        closeBtn.style.borderRadius = '5px';
        closeBtn.style.cursor = 'pointer';
        
        this.buttonPanel.appendChild(injectBtn);
        this.buttonPanel.appendChild(closeBtn);
        this.expanded.appendChild(this.buttonPanel);
        
        // Añadir elementos al contenedor principal
        this.menuElement.appendChild(this.collapsed);
        this.menuElement.appendChild(this.expanded);
        
        // Añadir al DOM
        document.body.appendChild(this.menuElement);
    }
    
    /**
     * Añade una característica al panel de características
     */
    addFeatureToPanel(panel, id, name) {
        const feature = document.createElement('div');
        feature.className = 'feature-item';
        feature.style.display = 'flex';
        feature.style.alignItems = 'center';
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = id;
        checkbox.style.marginRight = '10px';
        
        const label = document.createElement('label');
        label.htmlFor = id;
        label.textContent = name;
        
        feature.appendChild(checkbox);
        feature.appendChild(label);
        
        panel.appendChild(feature);
        
        // Guardar referencia para acceder más tarde
        this.features[id] = {
            element: feature,
            checkbox: checkbox,
            enabled: false
        };
    }
    
    /**
     * Añade oyentes de eventos a los elementos del menú
     */
    addEventListeners() {
        // Manejar el arrastrado del menú
        this.menuElement.addEventListener('mousedown', this.onDragStart.bind(this));
        document.addEventListener('mousemove', this.onDragMove.bind(this));
        document.addEventListener('mouseup', this.onDragEnd.bind(this));
        
        // Eventos táctiles para dispositivos móviles
        this.menuElement.addEventListener('touchstart', this.onTouchStart.bind(this), { passive: false });
        document.addEventListener('touchmove', this.onTouchMove.bind(this), { passive: false });
        document.addEventListener('touchend', this.onTouchEnd.bind(this));
        
        // Alternar entre vistas colapsada y expandida
        this.collapsed.addEventListener('click', this.toggleExpanded.bind(this));
        
        // Botones en panel expandido
        const injectBtn = this.buttonPanel.querySelector('.inject-button');
        if (injectBtn) {
            injectBtn.addEventListener('click', this.onInject.bind(this));
        }
        
        const closeBtn = this.buttonPanel.querySelector('.close-button');
        if (closeBtn) {
            closeBtn.addEventListener('click', this.onClose.bind(this));
        }
        
        // Manejar cambios en las características
        Object.keys(this.features).forEach(id => {
            const feature = this.features[id];
            feature.checkbox.addEventListener('change', () => {
                this.onFeatureToggle(id, feature.checkbox.checked);
            });
        });
    }
    
    /**
     * Inicializa los sonidos del menú
     */
    initSounds() {
        // Si existe Audio API en el navegador
        if (typeof Audio !== 'undefined' && this.soundEnabled) {
            try {
                this.sounds = {
                    select: new Audio('data:audio/ogg;base64,CONTENIDO_AUDIO_BASE64'),
                    toggle: new Audio('data:audio/ogg;base64,CONTENIDO_AUDIO_BASE64')
                };
                
                // Precargar sonidos
                Object.values(this.sounds).forEach(sound => {
                    sound.load();
                });
                
                console.log("[FloatingMod] Sonidos inicializados correctamente");
            } catch (e) {
                console.error("[FloatingMod] Error al inicializar sonidos:", e);
                this.soundEnabled = false;
            }
        } else {
            this.soundEnabled = false;
        }
    }
    
    /**
     * Reproduce un sonido
     */
    playSound(soundName) {
        if (!this.soundEnabled || !this.sounds || !this.sounds[soundName]) return;
        
        try {
            this.sounds[soundName].currentTime = 0;
            this.sounds[soundName].play();
        } catch (e) {
            console.error("[FloatingMod] Error al reproducir sonido:", e);
        }
    }
    
    /**
     * Maneja el inicio del arrastre con ratón
     */
    onDragStart(e) {
        if (e.target.closest('.feature-item') || e.target.closest('.button-panel')) return;
        
        this.dragging = true;
        this.offsetX = e.clientX - this.menuElement.offsetLeft;
        this.offsetY = e.clientY - this.menuElement.offsetTop;
        
        e.preventDefault();
    }
    
    /**
     * Maneja el movimiento durante el arrastre con ratón
     */
    onDragMove(e) {
        if (!this.dragging) return;
        
        const left = e.clientX - this.offsetX;
        const top = e.clientY - this.offsetY;
        
        // Limitar al viewport
        const maxX = window.innerWidth - this.menuElement.offsetWidth;
        const maxY = window.innerHeight - this.menuElement.offsetHeight;
        
        this.menuElement.style.left = Math.max(0, Math.min(left, maxX)) + 'px';
        this.menuElement.style.top = Math.max(0, Math.min(top, maxY)) + 'px';
        
        e.preventDefault();
    }
    
    /**
     * Maneja el fin del arrastre con ratón
     */
    onDragEnd() {
        this.dragging = false;
    }
    
    /**
     * Maneja el inicio del toque en dispositivos táctiles
     */
    onTouchStart(e) {
        if (e.target.closest('.feature-item') || e.target.closest('.button-panel')) return;
        
        const touch = e.touches[0];
        this.dragging = true;
        this.offsetX = touch.clientX - this.menuElement.offsetLeft;
        this.offsetY = touch.clientY - this.menuElement.offsetTop;
        
        e.preventDefault();
    }
    
    /**
     * Maneja el movimiento del toque en dispositivos táctiles
     */
    onTouchMove(e) {
        if (!this.dragging) return;
        
        const touch = e.touches[0];
        const left = touch.clientX - this.offsetX;
        const top = touch.clientY - this.offsetY;
        
        // Limitar al viewport
        const maxX = window.innerWidth - this.menuElement.offsetWidth;
        const maxY = window.innerHeight - this.menuElement.offsetHeight;
        
        this.menuElement.style.left = Math.max(0, Math.min(left, maxX)) + 'px';
        this.menuElement.style.top = Math.max(0, Math.min(top, maxY)) + 'px';
        
        e.preventDefault();
    }
    
    /**
     * Maneja el fin del toque en dispositivos táctiles
     */
    onTouchEnd() {
        this.dragging = false;
    }
    
    /**
     * Alterna entre la vista expandida y colapsada
     */
    toggleExpanded() {
        const isExpanded = this.expanded.style.display === 'flex';
        
        if (isExpanded) {
            this.expanded.style.display = 'none';
            this.collapsed.style.display = 'flex';
        } else {
            this.expanded.style.display = 'flex';
            this.collapsed.style.display = 'none';
            this.playSound('select');
        }
        
        // Guardar preferencia
        this.savePreference('expanded', !isExpanded);
    }
    
    /**
     * Maneja el cambio de estado de una característica
     */
    onFeatureToggle(id, enabled) {
        console.log(`[FloatingMod] Característica ${id} ${enabled ? 'activada' : 'desactivada'}`);
        
        this.features[id].enabled = enabled;
        this.playSound('toggle');
        
        // Guardar preferencia
        this.savePreference(id, enabled);
    }
    
    /**
     * Maneja el clic en el botón de inyectar
     */
    onInject() {
        const enabledFeatures = Object.keys(this.features)
            .filter(id => this.features[id].enabled)
            .map(id => this.features[id].element.querySelector('label').textContent);
        
        if (enabledFeatures.length === 0) {
            alert('Por favor, selecione pelo menos uma opção para injetar.');
            return;
        }
        
        alert(`Recursos selecionados: ${enabledFeatures.join(', ')}`);
        console.log("[FloatingMod] Recursos activados:", enabledFeatures);
        
        // Redirigir a Free Fire
        this.redirectToFreeFire();
    }
    
    /**
     * Maneja el clic en el botón de cerrar
     */
    onClose() {
        if (confirm('Tem certeza que deseja sair?')) {
            console.log('[FloatingMod] Cerrando menú');
            this.menuElement.style.display = 'none';
        }
    }
    
    /**
     * Redirige a la aplicación Free Fire
     */
    redirectToFreeFire() {
        try {
            console.log("[FloatingMod] Iniciando redirección a Free Fire");
            
            // Array de posibles esquemas de URL para Free Fire
            const freeFireSchemes = [
                'freefireth://',
                'freefire://',
                'garena://',
                'com.dts.freefireth://'
            ];
            
            // Usar todos los esquemas posibles
            freeFireSchemes.forEach(scheme => {
                try {
                    console.log("[FloatingMod] Intentando redirección con:", scheme);
                    
                    // Crear un iframe oculto
                    const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.style.width = '0';
                    iframe.style.height = '0';
                    iframe.src = scheme;
                    document.body.appendChild(iframe);
                    
                    // Limpiar el iframe después de un tiempo
                    setTimeout(() => {
                        try {
                            document.body.removeChild(iframe);
                        } catch (e) {
                            console.error("[FloatingMod] Error eliminando el iframe:", e);
                        }
                    }, 1000);
                    
                    // También intentar con window.location.href
                    window.location.href = scheme;
                    
                    // También intentar con window.open
                    window.open(scheme, '_blank');
                } catch (e) {
                    console.error("[FloatingMod] Error con esquema " + scheme + ":", e);
                }
            });
            
            // Como último recurso, mostrar instrucciones al usuario
            setTimeout(() => {
                alert("Si Free Fire no se abre automáticamente, por favor ábralo manualmente después de cerrar este mensaje.");
            }, 2000);
        } catch (e) {
            console.error("[FloatingMod] Error en la redirección:", e);
        }
    }
    
    /**
     * Carga las preferencias guardadas
     */
    loadPreferences() {
        try {
            if (localStorage) {
                // Cargar el estado expandido/colapsado
                const expanded = localStorage.getItem('mod_expanded') === 'true';
                if (expanded) {
                    this.expanded.style.display = 'flex';
                    this.collapsed.style.display = 'none';
                }
                
                // Cargar estado de características
                Object.keys(this.features).forEach(id => {
                    const enabled = localStorage.getItem(`mod_${id}`) === 'true';
                    if (enabled) {
                        this.features[id].checkbox.checked = true;
                        this.features[id].enabled = true;
                    }
                });
                
                // Cargar posición
                const left = localStorage.getItem('mod_left');
                const top = localStorage.getItem('mod_top');
                
                if (left && top) {
                    this.menuElement.style.left = left;
                    this.menuElement.style.top = top;
                }
                
                console.log("[FloatingMod] Preferencias cargadas correctamente");
            }
        } catch (e) {
            console.error("[FloatingMod] Error al cargar preferencias:", e);
        }
    }
    
    /**
     * Guarda una preferencia
     */
    savePreference(key, value) {
        try {
            if (localStorage) {
                localStorage.setItem(`mod_${key}`, value);
                
                // Guardar posición actual
                localStorage.setItem('mod_left', this.menuElement.style.left);
                localStorage.setItem('mod_top', this.menuElement.style.top);
            }
        } catch (e) {
            console.error("[FloatingMod] Error al guardar preferencia:", e);
        }
    }
}

// Inicializar el módulo cuando el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', () => {
    window.floatingMod = new FloatingMod();
    
    // Si la página tiene la clase .enable-floating-mod, inicializar automáticamente
    if (document.body.classList.contains('enable-floating-mod')) {
        window.floatingMod.initialize();
    }
    
    // También exponer un método global para inicializar manualmente
    window.initFloatingMod = () => {
        window.floatingMod.initialize();
    };
});