/**
 * Módulo ESPView para efectos visuales en la web
 * Adaptado de la versión Android para funcionar en navegadores web
 */

class ESPView {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.isRunning = false;
        this.lastTime = 0;
        this.FPS = 30;
        this.sleepTime = 1000 / this.FPS;
        this.colors = {
            stroke: { r: 0, g: 0, b: 0, a: 255 },
            fill: { r: 0, g: 0, b: 0, a: 255 },
            text: { r: 255, g: 255, b: 255, a: 255 }
        };
        this.initialized = false;
        this.screenWidth = window.innerWidth;
        this.screenHeight = window.innerHeight;
        this.date = new Date();
        this.formatter = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        this.dateFormatter = new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    /**
     * Inicializa el ESP View
     */
    initialize() {
        if (this.initialized) return;
        
        console.log("[ESPView] Inicializando...");
        
        // Crear canvas
        this.createCanvas();
        
        // Configurar canvas
        this.setupCanvas();
        
        // Iniciar bucle de renderizado
        this.startRenderLoop();
        
        // Agregar oyentes para redimensionar
        window.addEventListener('resize', this.onResize.bind(this));
        
        this.initialized = true;
        console.log("[ESPView] Inicializado correctamente");
    }
    
    /**
     * Crea el elemento canvas
     */
    createCanvas() {
        this.canvas = document.createElement('canvas');
        this.canvas.id = 'esp-view-canvas';
        this.canvas.style.position = 'fixed';
        this.canvas.style.top = '0';
        this.canvas.style.left = '0';
        this.canvas.style.width = '100%';
        this.canvas.style.height = '100%';
        this.canvas.style.pointerEvents = 'none';
        this.canvas.style.zIndex = '9998';
        document.body.appendChild(this.canvas);
        
        this.ctx = this.canvas.getContext('2d');
    }
    
    /**
     * Configura el canvas para que se ajuste a la pantalla
     */
    setupCanvas() {
        this.screenWidth = window.innerWidth;
        this.screenHeight = window.innerHeight;
        
        // Configura el tamaño del canvas
        this.canvas.width = this.screenWidth * window.devicePixelRatio;
        this.canvas.height = this.screenHeight * window.devicePixelRatio;
        
        // Escalar según la relación de píxeles del dispositivo
        this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    }
    
    /**
     * Inicia el bucle de renderizado
     */
    startRenderLoop() {
        this.isRunning = true;
        this.render();
    }
    
    /**
     * Maneja el evento de redimensionamiento de la ventana
     */
    onResize() {
        this.setupCanvas();
    }
    
    /**
     * Bucle principal de renderizado
     */
    render(timestamp) {
        if (!this.isRunning) return;
        
        // Calcular delta time
        if (!timestamp) timestamp = 0;
        const delta = timestamp - this.lastTime;
        
        if (delta >= this.sleepTime) {
            this.lastTime = timestamp;
            
            // Limpiar canvas
            this.clearCanvas();
            
            // Actualizar fecha
            this.date.setTime(Date.now());
            
            // Dibujar elementos
            this.draw();
        }
        
        // Programar siguiente frame
        requestAnimationFrame(this.render.bind(this));
    }
    
    /**
     * Limpia el canvas
     */
    clearCanvas() {
        this.ctx.clearRect(0, 0, this.screenWidth, this.screenHeight);
    }
    
    /**
     * Dibuja elementos en el canvas
     */
    draw() {
        // Dibujar fecha y hora
        const timeStr = this.formatter.format(this.date);
        const dateStr = this.dateFormatter.format(this.date);
        this.drawText(this.ctx, 255, 255, 255, 0, `                        ${dateStr}  ${timeStr}`, 50, 40, 20);
        
        // Dibujar otros elementos
        this.drawOverlay();
    }
    
    /**
     * Dibuja el overlay principal
     */
    drawOverlay() {
        // Implementar elementos específicos del overlay aquí
        // Por ejemplo, líneas, círculos, rectángulos, etc.
        
        // Ejemplo: Dibujar un recuadro semi-transparente en el centro
        this.drawRect(this.ctx, 100, 0, 120, 255, 2, 
                     this.screenWidth / 2 - 100, 
                     this.screenHeight / 2 - 100, 
                     200, 200);
        
        // Ejemplo: Dibujar líneas cruzadas
        this.drawLine(this.ctx, 100, 255, 0, 0, 1, 
                     this.screenWidth / 2, 0, 
                     this.screenWidth / 2, this.screenHeight);
        
        this.drawLine(this.ctx, 100, 255, 0, 0, 1, 
                     0, this.screenHeight / 2, 
                     this.screenWidth, this.screenHeight / 2);
    }
    
    /**
     * Dibuja un texto en el canvas
     */
    drawText(ctx, a, r, g, b, txt, posX, posY, size) {
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
        ctx.font = `${size}px Arial`;
        ctx.textAlign = 'center';
        ctx.fillText(txt, posX, posY);
    }
    
    /**
     * Dibuja una línea en el canvas
     */
    drawLine(ctx, a, r, g, b, lineWidth, fromX, fromY, toX, toY) {
        ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
        ctx.lineWidth = lineWidth;
        ctx.beginPath();
        ctx.moveTo(fromX, fromY);
        ctx.lineTo(toX, toY);
        ctx.stroke();
    }
    
    /**
     * Dibuja un círculo en el canvas
     */
    drawCircle(ctx, a, r, g, b, stroke, posX, posY, radius) {
        ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
        ctx.lineWidth = stroke;
        ctx.beginPath();
        ctx.arc(posX, posY, radius, 0, 2 * Math.PI);
        ctx.stroke();
    }
    
    /**
     * Dibuja un círculo relleno en el canvas
     */
    drawFilledCircle(ctx, a, r, g, b, posX, posY, radius) {
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
        ctx.beginPath();
        ctx.arc(posX, posY, radius, 0, 2 * Math.PI);
        ctx.fill();
    }
    
    /**
     * Dibuja un rectángulo en el canvas
     */
    drawRect(ctx, a, r, g, b, stroke, x, y, width, height) {
        ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
        ctx.lineWidth = stroke;
        ctx.strokeRect(x, y, width, height);
    }
    
    /**
     * Dibuja un rectángulo relleno en el canvas
     */
    drawFilledRect(ctx, a, r, g, b, x, y, width, height) {
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
        ctx.fillRect(x, y, width, height);
    }
    
    /**
     * Detiene el renderizado
     */
    stop() {
        this.isRunning = false;
    }
    
    /**
     * Reinicia el renderizado
     */
    resume() {
        if (!this.isRunning) {
            this.isRunning = true;
            this.render();
        }
    }
    
    /**
     * Limpia y elimina el canvas
     */
    destroy() {
        this.stop();
        if (this.canvas && this.canvas.parentNode) {
            this.canvas.parentNode.removeChild(this.canvas);
        }
        this.canvas = null;
        this.ctx = null;
        this.initialized = false;
    }
}

// Inicializar el módulo cuando el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', () => {
    window.espView = new ESPView();
    
    // Si la página tiene la clase .enable-esp-view, inicializar automáticamente
    if (document.body.classList.contains('enable-esp-view')) {
        window.espView.initialize();
    }
    
    // También exponer un método global para inicializar manualmente
    window.initESPView = () => {
        window.espView.initialize();
    };
});