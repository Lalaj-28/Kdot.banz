//#ifndef STRUCTSCOMM_H
//#define STRUCTSCOMM_H
//#pragma once

//#include <iostream>
//#include <string>
//#include <thread>
//#include <chrono>
//#include <functional>
//#include <vector>
//#include <list>
//using namespace std;

var maxplayerCount = 54;
var maxvehicleCount = 54;
var maxitemsCount = 200;

class Color {
        constructor(r, g, b, a = 255) {
                this.r = r;
                this.g = g;
                this.b = b;
                this.a = a;
        }

        static Black(){
                return new Color(0, 0, 0);
        }

        static White(){
                return new Color(255, 255, 255);
        }

        static Green(){
                return new Color(0, 255, 0);
        }
        
        static Blue(){
                return new Color(0, 0, 255);
        }
        
        static Cyan(){
                return new Color(0, 255, 255);
        }
        
        static DarkGolden(){
                return new Color(218,165,32);
        }
        
        static Indigo(){
                return new Color(75,0,130);
        }
        
        static Purple(){
                return new Color(128,0,128);
        }
        
        static Pink() {
                return new Color(255,192,203);
        }
        
        static Red() {
                return new Color(255, 0, 0);
        }
        
        static Yellow() {
                return new Color(255, 255, 0);
        }
        
        static Magenta() {
                return new Color(255, 0, 255);
        }
}

class Rect {
        constructor(x = 0, y = 0, width = 0, height = 0) {
                this.x = x;
                this.y = y;
                this.width = width;
                this.height = height;
        }

        equals(src) {
                return (src.x === this.x && src.y === this.y && src.height === this.height &&
                                src.width === this.width);
        }

        notEquals(src) {
                return (src.x !== this.x && src.y !== this.y && src.height !== this.height &&
                                src.width !== this.width);
        }
}

class Vector2 {
    constructor(x = 0, y = 0) {
        this.X = x;
        this.Y = y;
    }
}

class Vector3 {
    constructor(x = 0, y = 0, z = 0) {
        this.X = x;
        this.Y = y;
        this.Z = z;
    }

    static Dot(v1, v2) {
        return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z;
    }
}

class FMatrix {
    constructor() {
        this.M = Array(4).fill().map(() => Array(4).fill(0));
    }
}

class Quat {
    constructor(x = 0, y = 0, z = 0, w = 0) {
        this.X = x;
        this.Y = y;
        this.Z = z;
        this.W = w;
    }
}

class FTransform {
    constructor() {
        this.Rotation = new Quat();
        this.Translation = new Vector3();
        this.Scale3D = new Vector3(1, 1, 1);
    }
}

function MatrixToVector(matrix) {
        return new Vector3(matrix.M[3][0], matrix.M[3][1], matrix.M[3][2]);
}

function MatrixMulti(m1, m2) {
        var matrix = new FMatrix();
        for (var i = 0; i < 4; i++) {
                for (var j = 0; j < 4; j++) {
                        for (var k = 0; k < 4; k++) {
                                matrix.M[i][j] += m1.M[i][k] * m2.M[k][j];
                        }
                }
        }
        return matrix;
}

function TransformToMatrix(transform) {
        var matrix = new FMatrix();

        matrix.M[3][0] = transform.Translation.X;
        matrix.M[3][1] = transform.Translation.Y;
        matrix.M[3][2] = transform.Translation.Z;

        var x2 = transform.Rotation.X + transform.Rotation.X;
        var y2 = transform.Rotation.Y + transform.Rotation.Y;
        var z2 = transform.Rotation.Z + transform.Rotation.Z;

        var xx2 = transform.Rotation.X * x2;
        var yy2 = transform.Rotation.Y * y2;
        var zz2 = transform.Rotation.Z * z2;

        matrix.M[0][0] = (1.0 - (yy2 + zz2)) * transform.Scale3D.X;
        matrix.M[1][1] = (1.0 - (xx2 + zz2)) * transform.Scale3D.Y;
        matrix.M[2][2] = (1.0 - (xx2 + yy2)) * transform.Scale3D.Z;

        var yz2 = transform.Rotation.Y * z2;
        var wx2 = transform.Rotation.W * x2;
        matrix.M[2][1] = (yz2 - wx2) * transform.Scale3D.Z;
        matrix.M[1][2] = (yz2 + wx2) * transform.Scale3D.Y;

        var xy2 = transform.Rotation.X * y2;
        var wz2 = transform.Rotation.W * z2;
        matrix.M[1][0] = (xy2 - wz2) * transform.Scale3D.Y;
        matrix.M[0][1] = (xy2 + wz2) * transform.Scale3D.X;

        var xz2 = transform.Rotation.X * z2;
        var wy2 = transform.Rotation.W * y2;
        matrix.M[2][0] = (xz2 + wy2) * transform.Scale3D.Z;
        matrix.M[0][2] = (xz2 - wy2) * transform.Scale3D.X;

        matrix.M[0][3] = 0;
        matrix.M[1][3] = 0;
        matrix.M[2][3] = 0;
        matrix.M[3][3] = 1;

        return matrix;
}

class FRotator {
        constructor(pitch = 0, yaw = 0, roll = 0) {
                this.Pitch = pitch;
                this.Yaw = yaw;
                this.Roll = roll;
        }
}

function RotatorToMatrix(rotation) {
        var radPitch = rotation.Pitch * (Math.PI / 180.0);
        var radYaw = rotation.Yaw * (Math.PI / 180.0);
        var radRoll = rotation.Roll * (Math.PI / 180.0);

        var SP = Math.sin(radPitch);
        var CP = Math.cos(radPitch);
        var SY = Math.sin(radYaw);
        var CY = Math.cos(radYaw);
        var SR = Math.sin(radRoll);
        var CR = Math.cos(radRoll);

        var matrix = new FMatrix();

        matrix.M[0][0] = (CP * CY);
        matrix.M[0][1] = (CP * SY);
        matrix.M[0][2] = (SP);
        matrix.M[0][3] = 0;

        matrix.M[1][0] = (SR * SP * CY - CR * SY);
        matrix.M[1][1] = (SR * SP * SY + CR * CY);
        matrix.M[1][2] = (-SR * CP);
        matrix.M[1][3] = 0;

        matrix.M[2][0] = (-(CR * SP * CY + SR * SY));
        matrix.M[2][1] = (CY * SR - CR * SP * SY);
        matrix.M[2][2] = (CR * CP);
        matrix.M[2][3] = 0;

        matrix.M[3][0] = 0;
        matrix.M[3][1] = 0;
        matrix.M[3][2] = 0;
        matrix.M[3][3] = 1;

        return matrix;
}

class MinimalViewInfo {
        constructor() {
                this.Location = new Vector3();
                this.Rotation = new FRotator();
                this.FOV = 90.0;
        }
}

function WorldToScreen(worldLocation, camViewInfo, width, height) {
        var tempMatrix = RotatorToMatrix(camViewInfo.Rotation);

        var vAxisX = new Vector3(tempMatrix.M[0][0], tempMatrix.M[0][1], tempMatrix.M[0][2]);
        var vAxisY = new Vector3(tempMatrix.M[1][0], tempMatrix.M[1][1], tempMatrix.M[1][2]);
        var vAxisZ = new Vector3(tempMatrix.M[2][0], tempMatrix.M[2][1], tempMatrix.M[2][2]);

        var vDelta = new Vector3(
                worldLocation.X - camViewInfo.Location.X,
                worldLocation.Y - camViewInfo.Location.Y,
                worldLocation.Z - camViewInfo.Location.Z
        );

        var vTransformed = new Vector3(
                Vector3.Dot(vDelta, vAxisY),
                Vector3.Dot(vDelta, vAxisZ),
                Vector3.Dot(vDelta, vAxisX)
        );

        if (vTransformed.Z < 1.0) {
                vTransformed.Z = 1.0;
        }

        var fov = camViewInfo.FOV;
        var screenCenterX = (width / 2.0);
        var screenCenterY = (height / 2.0);

        return new Vector2(
                (screenCenterX + vTransformed.X * (screenCenterX / Math.tan(fov * (Math.PI / 360.0))) / vTransformed.Z),
                (screenCenterY - vTransformed.Y * (screenCenterX / Math.tan(fov * (Math.PI / 360.0))) / vTransformed.Z)
        );
}

//#endif