/**
 * ZSensi - Script principal
 * Para uso en Netlify
 */

// Función principal al cargar el documento
document.addEventListener('DOMContentLoaded', function() {
    console.log("ZSensi cargando...");
    
    // Inicializar los módulos si están disponibles
    if (window.initSounds) {
        window.initSounds();
    }
    
    if (window.initFloatingMod) {
        window.initFloatingMod();
    }
    
    if (window.initESPView) {
        window.initESPView();
    }
    
    // Configurar eventos para formularios
    setupForms();
    
    // Inicializar particles.js si está disponible
    initParticles();
    
    console.log("ZSensi cargado correctamente");
});

// Inicializar particles.js para el fondo
function initParticles() {
    if (typeof particlesJS !== 'undefined') {
        particlesJS('particles-js', {
            "particles": {
                "number": {
                    "value": 80,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#ffffff"
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                    "polygon": {
                        "nb_sides": 5
                    }
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                        "speed": 1,
                        "opacity_min": 0.1,
                        "sync": false
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                    "anim": {
                        "enable": false,
                        "speed": 40,
                        "size_min": 0.1,
                        "sync": false
                    }
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#ffffff",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                    "attract": {
                        "enable": false,
                        "rotateX": 600,
                        "rotateY": 1200
                    }
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "repulse"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 400,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "bubble": {
                        "distance": 400,
                        "size": 40,
                        "duration": 2,
                        "opacity": 8,
                        "speed": 3
                    },
                    "repulse": {
                        "distance": 200,
                        "duration": 0.4
                    },
                    "push": {
                        "particles_nb": 4
                    },
                    "remove": {
                        "particles_nb": 2
                    }
                }
            },
            "retina_detect": true
        });
    } else {
        console.log("particles.js no está disponible");
    }
}

// Configurar eventos para formularios
function setupForms() {
    // Formulario de clave en index.html
    const keyForm = document.getElementById('keyForm');
    if (keyForm) {
        keyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const keyInput = document.getElementById('keyInput');
            const errorMessage = document.getElementById('errorMessage');
            
            if (keyInput && keyInput.value.trim() === 'Zsensi-IOS') {
                console.log("Clave correcta ingresada:", keyInput.value);
                
                // Ocultar mensaje de error si estaba visible
                if (errorMessage) {
                    errorMessage.style.display = 'none';
                }
                
                // Reproducir sonido si está disponible
                if (window.playSound) {
                    window.playSound('select');
                }
                
                // Redirigir a la URL específica de Netlify
                setTimeout(function() {
                    window.location.href = 'https://courageous-selkie-167ccf.netlify.app/';
                }, 500);
            } else {
                console.log("Clave incorrecta:", keyInput ? keyInput.value : "");
                
                // Mostrar mensaje de error
                if (errorMessage) {
                    errorMessage.style.display = 'block';
                }
                
                // Reproducir sonido de error si está disponible
                if (window.playSound) {
                    window.playSound('off');
                }
            }
        });
    }
    
    // Formulario de opciones en opciones.html
    const optionsForm = document.getElementById('options-form');
    if (optionsForm) {
        optionsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Recopilar opciones seleccionadas
            const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
            const options = Array.from(checkboxes).map(cb => cb.value);
            
            if (options.length > 0) {
                console.log("Opciones seleccionadas:", options);
                
                // Reproducir sonido si está disponible
                if (window.playSound) {
                    window.playSound('select');
                }
                
                // Intentar redirigir a Free Fire
                redirectToFreeFire();
            } else {
                alert("Por favor selecciona al menos una opción");
            }
        });
    }
}

// Función para redirigir a Free Fire
function redirectToFreeFire() {
    try {
        console.log("Iniciando redirección a Free Fire");
        
        // Array de posibles esquemas de URL para Free Fire
        const freeFireSchemes = [
            'freefireth://',
            'freefire://',
            'garena://',
            'com.dts.freefireth://'
        ];
        
        // Usar todos los esquemas posibles
        freeFireSchemes.forEach(scheme => {
            try {
                console.log("Intentando redirección con:", scheme);
                
                // Crear un iframe oculto
                const iframe = document.createElement('iframe');
                iframe.style.display = 'none';
                iframe.style.width = '0';
                iframe.style.height = '0';
                iframe.src = scheme;
                document.body.appendChild(iframe);
                
                // Limpiar el iframe después de un tiempo
                setTimeout(() => {
                    try {
                        document.body.removeChild(iframe);
                    } catch (e) {
                        console.error("Error eliminando el iframe:", e);
                    }
                }, 1000);
                
                // También intentar con window.location.href
                window.location.href = scheme;
                
                // También intentar con window.open
                window.open(scheme, '_blank');
            } catch (e) {
                console.error("Error con esquema " + scheme + ":", e);
            }
        });
        
        // Como último recurso, mostrar instrucciones al usuario
        setTimeout(() => {
            alert("Si Free Fire no se abre automáticamente, por favor ábralo manualmente después de cerrar este mensaje.");
        }, 2000);
    } catch (e) {
        console.error("Error en la redirección:", e);
    }
}