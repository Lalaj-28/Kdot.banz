/**
 * BuildConfig para web
 * Adaptado de la versión Android para funcionar en navegadores web
 */

// Simular el BuildConfig de Android
const BuildConfig = {
    DEBUG: true,
    VERSION_CODE: 1,
    VERSION_NAME: "1.0.0",
    APPLICATION_ID: "uk.lgl.modmenu",
    BUILD_TYPE: "debug",
    FLAVOR: "",
    
    // Método para comprobar si estamos en modo debug
    isDebug: function() {
        return this.DEBUG;
    },
    
    // Método para obtener la versión como string
    getVersionString: function() {
        return this.VERSION_NAME;
    }
};

// Exponer globalmente
window.BuildConfig = BuildConfig;

console.log("[BuildConfig] Inicializado: " + (BuildConfig.DEBUG ? "DEBUG" : "RELEASE"));