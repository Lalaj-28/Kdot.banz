//#ifndef ESP_H
//#define ESP_H

//#include <jni.h>
//#include "StructsCommon.h"

class ESP {
        constructor(canvas) {
                this._canvas = canvas;
        this._ctx = canvas ? canvas.getContext('2d') : null;
        }

        isValid() {
                return (this._canvas !== null && this._ctx !== null);
        }

        getWidth() {
                if (this.isValid()) {
                        return this._canvas.width;
                }
                return 0;
        }

        getHeight() {
                if (this.isValid()) {
                        return this._canvas.height;
                }
                return 0;
        }

        DrawLine(color, thickness, start, end) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.beginPath();
            ctx.moveTo(start.X, start.Y);
            ctx.lineTo(end.X, end.Y);
            ctx.strokeStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.lineWidth = thickness;
            ctx.stroke();
                }
        }

        DrawText(color, stroke, str, pos, size) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.font = `${size}px Arial`;
            ctx.fillStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.strokeStyle = `rgba(0, 0, 0, ${stroke / 10})`;
            if (stroke > 0) {
                ctx.lineWidth = stroke;
                ctx.strokeText(str, pos.X, pos.Y);
            }
            ctx.fillText(str, pos.X, pos.Y);
                }
        }
        
        DrawText1(color, txt, pos, size) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.font = `${size}px Arial`;
            ctx.fillStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.fillText(txt, pos.X, pos.Y);
                }
        }

        DrawName(color, stroke, str, pos, size) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.font = `bold ${size}px Arial`;
            ctx.fillStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.strokeStyle = `rgba(0, 0, 0, ${stroke / 10})`;
            if (stroke > 0) {
                ctx.lineWidth = stroke;
                ctx.strokeText(str, pos.X, pos.Y);
            }
            ctx.fillText(str, pos.X, pos.Y);
                }
        }

        DrawFilledCircle(color, pos, radius) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.beginPath();
            ctx.arc(pos.X, pos.Y, radius, 0, 2 * Math.PI, false);
            ctx.fillStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.fill();
                }
        }

        DrawFilledCircle1(color, pos, radius) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.beginPath();
            ctx.arc(pos.X, pos.Y, radius, 0, 2 * Math.PI, false);
            ctx.fillStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.fill();
                }
        }
        
        DrawCircle(color, stroke, pos, radius) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.beginPath();
            ctx.arc(pos.X, pos.Y, radius, 0, 2 * Math.PI, false);
            ctx.strokeStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.lineWidth = stroke;
            ctx.stroke();
                }
        }

        DrawFilledRect(color, pos, width, height) {
                if (this.isValid()) {
                        var ctx = this._ctx;
            ctx.fillStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
            ctx.fillRect(pos.X, pos.Y, width, height);
                }
        }

        DrawBox(color, stroke, rect) {
                var v1 = new Vector3(rect.x, rect.y);
                var v2 = new Vector3(rect.x + rect.width, rect.y);
                var v3 = new Vector3(rect.x + rect.width, rect.y + rect.height);
                var v4 = new Vector3(rect.x, rect.y + rect.height);

                this.DrawLine(color, stroke, v1, v2); // LINE UP
                this.DrawLine(color, stroke, v2, v3); // LINE RIGHT
                this.DrawLine(color, stroke, v3, v4); // LINE DOWN
                this.DrawLine(color, stroke, v4, v1); // LINE LEFT
        }

        DrawCrosshair(clr, center, size = 20) {
                var x = center.X - (size / 2.0);
                var y = center.Y - (size / 2.0);
                this.DrawLine(clr, 3, new Vector3(x, center.Y), new Vector3(x + size, center.Y));
                this.DrawLine(clr, 3, new Vector3(center.X, y), new Vector3(center.X, y + size));
        }
}

//#endif