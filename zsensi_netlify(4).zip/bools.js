//#ifndef BOOLS_H
//#define BOOLS_H

//#include <jni.h>
//#include <string>
//#include <cstdlib>
//#include <unistd.h>
//#include <sys/mman.h>
//#include <android/log.h>

var isESP = false;

var Eskeleton = false;
var indetifiq = "";
var isPlayerName = false;

var espIndetificar = false;

var isPlayerHealth = false;

var isTeamMateShow = false;

var color = false;
var isPlayer360 = false;

var isPlayerDistance = false;

var isCrosshair = false;

var isDrawCircle = false;

var isPlayerCount = false;

var LineColorBranco = Color.White();

var LineColorPreto = Color.Black();

var CrossColor = Color.White();

var CircleColor = Color.White();
var skeletoncolor;
var boxcolor;
var linecolor;
var distancecolor;
var mococolor;
var LineColor = 0;
var botcolor;
var CrossSize = 42;

var playerTextSize = 12;

var CircleSize = 22;

var Linesize = 1;

//#endif